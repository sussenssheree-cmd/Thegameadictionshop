SHAZZZZ ADD-ON FORGE - FINAL OFFLINE BUILD

Contents:
- index.html: updated website
- _headers: download headers for Netlify
- downloads/Shazzz_Dirt_to_Diamond.mcpack: single behavior pack
- downloads/Shazzz_Starter_Addon.mcaddon: bundle containing the same mcpack

Deploy the CONTENTS of this folder to the existing Netlify site in one production deployment. Do not upload this ZIP as a file to the live website.

Validation completed offline: ZIPs open, pack manifest JSON parses, recipe JSON parses, expected files are at the pack root, and website download paths match the files. Minecraft Android import cannot be simulated here. If Minecraft does not appear in Android's Open with list, the site cannot force that OS-level app association.
